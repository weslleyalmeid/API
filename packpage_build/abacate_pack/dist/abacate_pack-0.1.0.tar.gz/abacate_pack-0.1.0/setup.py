# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['abacate_pack']

package_data = \
{'': ['*']}

install_requires = \
['httpx>=0.23.0,<0.24.0']

entry_points = \
{'console_scripts': ['abacate-cli = abacate_pack.cli:cli']}

setup_kwargs = {
    'name': 'abacate-pack',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'weslleyalmeid',
    'author_email': 'weslley_fac@hotmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
